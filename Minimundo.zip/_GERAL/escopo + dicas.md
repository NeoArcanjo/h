Problema detectado: o sistema de sa�de, seja na rede particular, seja na p�blica, 
carece de registros e de integra��o dos prontu�rios m�dicos dos pacientes.
Cada consulta � tratada individualmente, n�o havendo correla��o entre hist�ricos 
de consultas/atendimentos de urg�ncia/emerg�ncia anteriores.

Proposta: Desenvolver integra��o entre as duas redes de sa�de e entre os diversos elementos que comp�em cada uma delas.
O sistema deve levar ao m�dico em atendimento informa��es detalhadas sobre o paciente, 
trazendo tamb�m informa��es como hist�rico de IMC, press�o arterial sist�mica, vacina��o, alergias e afins.
O sistema deve ser integrado ao digiSUS

Vers�es futuras: os dados obtidos n�o ser�o apenas arquivados. 
Ser�o usados para aprendizado de m�quina para desenvolver uma previs�o de doen�as e evolu��o 
de quadros de sa�de baseados em triagem hist�rica de indiv�duos


pip install PyMySQL
pip install PyMySQLDB
